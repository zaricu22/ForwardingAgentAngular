export interface AuthToken {
    value: string;
    username: string;
    role: string;
    idPreduzeca: number;
}
