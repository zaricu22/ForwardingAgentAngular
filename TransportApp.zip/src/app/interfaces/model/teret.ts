export interface Teret {
    idTeret: number;
    tezina: number;
    tip: string;
    opis: string;
}
