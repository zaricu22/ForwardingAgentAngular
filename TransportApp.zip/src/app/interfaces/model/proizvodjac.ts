export interface Proizvodjac {
    idProizvodjac: number;
    naziv: string;
    sediste: string;
    datumOsnivanja: Date;
    prihod: number;
    slika: string;
    email: string;
    telefon: string;
}
