export enum Role {
    Carrier = 'CARRIER',
    Manufacturer = 'MANUFACTURER'
}
